#!/usr/bin/env python
import dateutil.parser
import threading, logging, time, datetime
from time import strftime

from kafka.client import KafkaClient
from kafka.consumer import SimpleConsumer
from kafka.producer import SimpleProducer
from random import randrange, uniform

class Producer(threading.Thread):
    daemon = True

    def run(self):
        client = KafkaClient("localhost:9092")
        producer = SimpleProducer(client)

        while True:
            try :
                count = 0
                with open("sample_events.csv") as events:
                   for event in events:
                       line = event.replace("\"","") 
                       line = line.strip().split(",")

                       if len(line) != 8:
                           continue
#                       try :
#                           d = dateutil.parser.parse(line[0])
#                           timestamp  = d.strftime("%Y-%m-%d %H:%M:%S")
#                       except :
#                           continue
                       #Hack timestamp to generate dummy data
                       ts = time.time()
                       timestamp = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')
                       userId = line[1]
                       event = line[2]
                       eventType = line[3]
                       sku = line[4]
                       price = line[5]
                       searchString = line[6]
                       orderId = line[7]
                       t1 = str(timestamp) + "\t" + str(userId) + "\t" + event + "\t" + eventType + "\t" + str(sku) + "\t" + str(price) + "\t" + searchString + "\t" + orderId
                       print t1
                       count = count + 1
                       if count > 100 :
                           count = count % 100
                           time.sleep(1)
                       producer.send_messages('latestevent', t1)
#                       time.sleep(1)
            except :
                continue

class Consumer(threading.Thread):
    daemon = True

    def run(self):
        client = KafkaClient("localhost:9092")
        consumer = SimpleConsumer(client, "test-group", "my-topic")

        for message in consumer:
            print(message)

def main():
    threads = [
        Producer()
    ]

    for t in threads:
        t.start()

    while True:
        time.sleep(5) 

if __name__ == "__main__":
    logging.basicConfig(
        format='%(asctime)s.%(msecs)s:%(name)s:%(thread)d:%(levelname)s:%(process)d:%(message)s',
        level=logging.DEBUG
        )
    main()
