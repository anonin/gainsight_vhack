Please find the code to populate data to kafka & Receiving from kafka 
