package storm.kafka.trident.functions;

import java.util.*;
import java.text.*;
import java.sql.SQLException;
import storm.kafka.trident.mappings.ColumnMappings;
import backtype.storm.tuple.Values;
import storm.trident.operation.BaseFunction;
import storm.trident.operation.TridentCollector;
import storm.trident.tuple.TridentTuple;
import storm.kafka.trident.helpers.*;
import java.util.concurrent.TimeUnit;
public class EventFields extends BaseFunction {
    ColumnMappings           userIdToPincode;
    ColumnMappings           pidTobrand;
    ColumnMappings           pidToPname;
    ColumnMappings           pincodeToState;
    ColumnMappings           pincodeTodistrictName;
    ColumnMappings           userIdToDOB;
    DateFormat               formatter;
    public EventFields() {
        try {
            userIdToPincode = new ColumnMappings("select  userId as userId,  pincode as pincode from userMaster", "userId", "pincode");
            userIdToDOB = new ColumnMappings("select  userId as userId,  dob as dob from userMaster", "userId", "dob");
            pidTobrand = new ColumnMappings("select  sku as sku,  brand as brand from productMaster", "sku", "brand");
            pidToPname = new ColumnMappings("select  sku as sku,  name as name from productMaster", "sku", "name");
            pincodeToState = new ColumnMappings("select  pincode as pincode,  stateName as stateName from pincodeMaster", "pincode", "stateName");
            pincodeTodistrictName = new ColumnMappings("select  pincode as pincode,  districtName as districtName from pincodeMaster", "pincode", "districtName");
            formatter = new SimpleDateFormat("yy-MM-dd HH:mm:ss");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
    public void execute(TridentTuple tuple, TridentCollector collector) {
        String row = tuple.getStringByField("str");
        System.out.println(" Tuple is  " + row);
        if (row != null) {
            String[] split = row.split("\t");
            try {
                System.out.println(" Length is  " + split.length);
                if (split.length > 3) {
                    String ts = split[0];
                    String pincode = "-", brand = "-", state = "-", distrinctName = "-", searchString = "-", dob = "-";
                    long age = 0;
                    String userId = split[1];
                    if (userIdToPincode != null) {
                        pincode = userIdToPincode.getValue(userId);
                    }
                    if (userIdToDOB != null) {
                        dob = userIdToDOB.getValue(userId);
                        if (dob != null) {
                            //Approx Age calculation
                            age = (formatter.parse(ts).getTime() - formatter.parse(dob).getTime()) / (60 * 60 * 1000 * 24 * 365 * 21);
                        }
                    }
                    if (pincodeToState != null) {
                        state = pincodeToState.getValue(pincode);
                    }
                    if (pincodeTodistrictName != null) {
                        distrinctName = pincodeTodistrictName.getValue(pincode);
                    }
                    String event = split[2];
                    String eventType = "-", sku = "-", price = "-", orderId = "-", pname = "-";
                    if (split.length > 3) {
                        eventType = split[3];
                    }
                    if (split.length > 4) {
                        sku = split[4];
                        if (pidTobrand != null) {
                           brand = pidTobrand.getValue(sku); 
                           pname = pidToPname.getValue(sku); 
                        }
                    }
                    if (split.length > 5) {
                        price = split[5];
                    }
                    if (split.length > 6) {
                        searchString = split[6];
                    }
                    if (split.length > 7) {
                        orderId = split[7];
                    }
                    int year = 1970;
                    int month = 1;
                    int day = 1;
                    int hour = 0;
                    int min = 0;
                    if (ts != null) {
                        String[] yymmdd = ts.split("-");
                        if (yymmdd.length == 3) {
                            year = Integer.parseInt(yymmdd[0]);
                            month = Integer.parseInt(yymmdd[1]);
                            day = Integer.parseInt(yymmdd[2].split(" ")[0]);
                            String []hhMMss = (yymmdd[2].split(" ")[1]).split(":");
                            if (hhMMss.length > 2) {
                               hour = Integer.parseInt(hhMMss[0]);
                               min = Integer.parseInt(hhMMss[1]);
                            }
                        }
                    }
                    System.out.println(userId + " " + event + " " + eventType + " " + sku + " " + price + " " + searchString + " " + orderId + " " + year + " " +  month + " " + day + " " + hour + " " + min + " " + pincode + " " + brand + " " + state + " " + distrinctName + " " + dob + " " + age + " " + pname);
//                    collector.emit(new Values(userId, event, eventType, sku, price, searchString, orderId, year, month, day, hour, min, pincode, brand, state, distrinctName, age, pname));
//                    collector.emit(new Values(userId, event, eventType, sku, searchString, year, month, day, hour, brand, state, distrinctName, age, pname));
                    collector.emit(new Values(userId, year, month, day, hour, pname, eventType, event, brand));
                }
            } catch (Exception e) {
                System.out.println("Error processing tuple " + e.getMessage());
            }
        }
    }
}
