package storm.kafka.trident.functions;
import storm.trident.operation.BaseFunction;
import storm.trident.operation.TridentCollector;
import storm.trident.tuple.TridentTuple;

public class Print extends BaseFunction {
    /**
     * 
     */
    public void execute(TridentTuple tuple, TridentCollector collector) {
//"sku", "year", "month", "day", "state", "distrinctName", "brand", "age", "pname"
        System.out.println(tuple.getIntegerByField("year") + " " + tuple.getIntegerByField("month") + " " + tuple.getIntegerByField("day") + " " + tuple.getStringByField("sku") + " " + tuple.getStringByField("pname") + " " + tuple.getLongByField("age") + " " + tuple.getStringByField("state") + " " + tuple.getStringByField("distrinctName") + " "  + tuple.getStringByField("brand") + " " + tuple.getLongByField("views"));
//        System.out.println(tuple.getIntegerByField("year") + " " + tuple.getIntegerByField("month") + " " + tuple.getIntegerByField("day") + " " + tuple.getStringByField("sku") + " " + tuple.getStringByField("pname") + " " + tuple.getLongByField("age") + " " + tuple.getStringByField("state"));
    }
}
