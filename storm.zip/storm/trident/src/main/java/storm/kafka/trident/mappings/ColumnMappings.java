package storm.kafka.trident.mappings;

import java.io.Serializable;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;

import storm.kafka.trident.database.*;
import storm.trident.operation.TridentOperationContext;

/**
 * Class that will create Mapping
 */
public class ColumnMappings implements Serializable {
    /**
     * 
     */
    MysqlConnector          dbConnection;
    String                  keyColumn;
    String                  valueColumn;
    String                  tableName;
    String                  startDateTimeColumn;
    String                  endDateTimeColumn;
    String                  query;
    HashMap<String, String> hashMap;
    int flag = 0;
    long                            startTime   = 0;
    long                            timeElapsed = 0;


    public ColumnMappings(String keyColumn, String valueColumn, String tableName,
            String startDateTimeColumn, String endDateTimeColumn)
            throws ClassNotFoundException, SQLException {
        String dbUrl = "jdbc:mysql://localhost:3306/gainsight?user=root&password=mysql";
        this.dbConnection = new MysqlConnector(dbUrl);
        this.keyColumn = keyColumn;
        this.valueColumn = valueColumn;
        this.tableName = tableName;
        this.startDateTimeColumn = startDateTimeColumn;
        this.endDateTimeColumn = endDateTimeColumn;
        this.hashMap = new HashMap<String, String>();
    }

    public ColumnMappings(String databaseName, String keyColumn,
            String valueColumn, String tableName, String startDateTimeColumn,
            String endDateTimeColumn) throws ClassNotFoundException,
            SQLException {
        String dbUrl = "jdbc:mysql://localhost:3306/gainsight?user=root&password=mysql";
        this.dbConnection = new MysqlConnector(dbUrl);
        this.keyColumn = keyColumn;
        this.valueColumn = valueColumn;
        this.tableName = tableName;
        this.startDateTimeColumn = startDateTimeColumn;
        this.endDateTimeColumn = endDateTimeColumn;
        this.hashMap = new HashMap<String, String>();
    }

    public ColumnMappings(String query, String keyColumn, String valueColumn)
            throws ClassNotFoundException, SQLException {
        String dbUrl = "jdbc:mysql://localhost:3306/gainsight?user=root&password=mysql";
        this.dbConnection = new MysqlConnector(dbUrl);
        this.keyColumn = keyColumn;
        this.valueColumn = valueColumn;
        this.query = query;
        this.hashMap = new HashMap<String, String>();
    }

    public ColumnMappings(String databaseName, String query, String keyColumn,
            String valueColumn) throws ClassNotFoundException, SQLException {
        String dbUrl = "jdbc:mysql://localhost:3306/gainsight?user=root&password=mysql";
        this.dbConnection = new MysqlConnector(dbUrl);
        this.keyColumn = keyColumn;
        this.valueColumn = valueColumn;
        this.query = query;
        this.hashMap = new HashMap<String, String>();
    }

    public void cleanup() {

    }

    public String getValue(String key, String dateTime) {
        String value = "";
        if (hashMap.containsKey(key)) {
            value = hashMap.get(key);
        } else {
            refreshMapping(dateTime);
            value = hashMap.get(key);
        }

        return value;
    }

    public String getValue(String key) {
        String value = null;
        if (startTime == 0) {
            startTime = System.currentTimeMillis();
        }
        timeElapsed = System.currentTimeMillis() - startTime;
        
        if (hashMap.containsKey(key)) {
            value = hashMap.get(key);
        } else {
            if (flag == 0) {
                refreshMapping();
                flag = 1;
            }
            if (timeElapsed > 360000) {
                startTime = System.currentTimeMillis();
                refreshMapping();
            }            
            if (hashMap.containsKey(key)) {
                value = hashMap.get(key);
            }
        }
        return value;
    }

    private void refreshMapping(String DateTime) {
        String q = "select " + this.keyColumn + ", " + this.valueColumn
                + " from " + this.tableName;
        q += " where " + this.startDateTimeColumn + " <= \"" + DateTime + "\"";
        q += " and " + this.endDateTimeColumn + "   >= \"" + DateTime + "\"";
        ArrayList<HashMap<String, String>> al = dbConnection.executeQuery(q);
        HashMap<String, String> hm;
        Iterator<HashMap<String, String>> itr = al.iterator();
        String key, value;
        hashMap = new HashMap<String, String>();
        while (itr.hasNext()) {
            hm = itr.next();
            key = hm.get(this.keyColumn);
            value = hm.get(this.valueColumn);
            hashMap.put(key, value);
        }
    }

    private void refreshMapping() {
        Calendar calendar = new GregorianCalendar();
        Runtime runtime = Runtime.getRuntime();
        int year = calendar.get(Calendar.YEAR);
        // Since Month in java starts with 0
        int month = calendar.get(Calendar.MONTH) + 1;
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        int hour = calendar.get(Calendar.HOUR);
        int min = calendar.get(Calendar.MINUTE);
        int sec = calendar.get(Calendar.SECOND);
        String datetime = year + "-" + month + "-" + day + " " + hour + ":"
                + min + ":00";
        if (query == null) {
            query = "select " + this.keyColumn + ", " + this.valueColumn
                    + " from " + this.tableName;
            query += " where " + this.startDateTimeColumn + " <= \"" + datetime
                    + "\"";
            query += " and " + this.endDateTimeColumn + "   >= \"" + datetime
                    + "\"";
        }
        ArrayList<HashMap<String, String>> al = dbConnection
                .executeQuery(query);
        HashMap<String, String> hm;
        Iterator<HashMap<String, String>> itr = al.iterator();
        String key, value;
        hashMap = new HashMap<String, String>();
        while (itr.hasNext()) {
            hm = itr.next();
            key = hm.get(this.keyColumn);
            value = hm.get(this.valueColumn);
            hashMap.put(key, value);
        }
    }
}

