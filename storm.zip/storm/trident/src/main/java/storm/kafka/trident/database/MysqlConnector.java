package storm.kafka.trident.database;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;

/*
 * Class that connects to the rdbms and returns a Connection object
 */
public class MysqlConnector implements Serializable {

    private Connection con     = null;
    private String     dbClass = "com.mysql.jdbc.Driver";
    private String     dbURL;

    /*
     * get connection and return a Connection object
     */
    public MysqlConnector(String sqlDBUrl) throws ClassNotFoundException,
            SQLException {
        dbURL = sqlDBUrl;
    }

    public ArrayList<HashMap<String, String>> executeQuery(String q) {
        try {
            Class.forName(dbClass);
            con = DriverManager.getConnection(dbURL);
            ArrayList<HashMap<String, String>> al = new ArrayList<HashMap<String, String>>();
            HashMap<String, String> hm;
            LinkedList colNames = new LinkedList();
            Statement s;
            s = con.createStatement();
            ResultSet rs = s.executeQuery(q);
            ResultSetMetaData md = rs.getMetaData();
            int numCols = md.getColumnCount();
            for (int i = 1; i <= numCols; i++) {
                colNames.add(md.getColumnName(i));
            }
            while (rs.next()) {
                hm = new HashMap<String, String>();
                for (int i = 1; i <= numCols; i++) {
                    hm.put((String) colNames.get(i - 1), rs.getString(i));
                }
                al.add(hm);
            }
          
            rs.close();
            s.close();
            con.close();
            return al;
        } catch (ClassNotFoundException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        } catch (SQLException e) {
            System.out.println(e);
        }
        return null;
    }

    /*
     * Perform a db query and which updates the database.
     */
    public void executeUpdate(String q) {
        try {
            Class.forName(dbClass);
            con = DriverManager.getConnection(dbURL);
            Statement s;
            s = con.createStatement();
            s.executeUpdate(q);
            s.close();
            con.close();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }
}

