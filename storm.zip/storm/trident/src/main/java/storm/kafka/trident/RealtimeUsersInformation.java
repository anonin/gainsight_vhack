package storm.kafka.trident;

import backtype.storm.Config;
import backtype.storm.LocalCluster;
import backtype.storm.LocalDRPC;
import backtype.storm.StormSubmitter;
import backtype.storm.generated.StormTopology;
import backtype.storm.spout.SchemeAsMultiScheme;
import backtype.storm.tuple.Fields;
import backtype.storm.utils.Utils;
import storm.kafka.BrokerHosts;
import storm.kafka.StringScheme;
import storm.kafka.ZkHosts;
import storm.kafka.trident.functions.EventFieldsForUsers;
import storm.kafka.trident.functions.Print;
import storm.kafka.trident.state.HazelCastStateFactory;
import storm.trident.state.mysql.MysqlState;
import storm.trident.state.mysql.MysqlStateConfig;
import storm.trident.state.StateType;
import storm.trident.TridentState;
import storm.trident.testing.MemoryMapState;
import storm.trident.TridentTopology;
import storm.trident.operation.builtin.Count;
import storm.trident.operation.builtin.FilterNull;
import storm.trident.operation.builtin.MapGet;
import storm.trident.operation.builtin.Sum;
import storm.trident.testing.Split;

import java.util.Arrays;

public class RealtimeUsersInformation {

    private final BrokerHosts brokerHosts;

    public RealtimeUsersInformation(String kafkaZookeeper) {
        brokerHosts = new ZkHosts(kafkaZookeeper);
    }

    public StormTopology buildTopology() {
        return buildTopology(null);
    }

    public StormTopology buildTopology(String name) {
        String dbUrl = "jdbc:mysql://localhost:3306/gainsight?user=root&password=mysql";
        System.out.println(dbUrl);
        // Creating configuration for persistence storage
        MysqlStateConfig mysqlconfig = new MysqlStateConfig();
        {
            mysqlconfig.setUrl(dbUrl);
            mysqlconfig.setTable("UsersTracking");
            mysqlconfig.setKeyColumns(new String[] { "timestamp", "activeUsers"});
            mysqlconfig.setValueColumns(new String[] {"dummyColumn"});
            mysqlconfig.setType(StateType.TRANSACTIONAL);
            mysqlconfig.setBatchSize(100);
            mysqlconfig.setCacheSize(1024 * 1024);
        }
        TridentKafkaConfig kafkaConfig = new TridentKafkaConfig(brokerHosts, "latestevent", name);
        kafkaConfig.bufferSizeBytes = 8 * 1024 * 1024;
        kafkaConfig.fetchSizeBytes = 8 * 1024 * 1024;
        kafkaConfig.scheme = new SchemeAsMultiScheme(new StringScheme());
        TransactionalTridentKafkaSpout kafkaSpout = new TransactionalTridentKafkaSpout(kafkaConfig);
        TridentTopology topology = new TridentTopology();
//userId, event, eventType, sku, searchString, year, month, day, hour, brand, state, distrinctName, age, pname
//userId, year, month, day, hour, pname
        topology.newStream("test", kafkaSpout).shuffle().parallelismHint(8).
                each(new Fields("str"), new EventFieldsForUsers(), new Fields("timestamp", "activeUsers"))
//                .each(new Fields("sku", "year", "month", "day", "state", "distrinctName", "brand", "age", "pname"), new Print(), new Fields("var"))
                .groupBy(new Fields("timestamp", "activeUsers"))
//                .persistentAggregate(MysqlState.newFactory(mysqlconfig), new Fields("sku", "year", "month", "day", "state", "distrinctName", "brand", "age", "pname"), new Count(), new Fields("views"))
                .persistentAggregate(MysqlState.newFactory(mysqlconfig), new Fields("timestamp", "activeUsers"), new Sum(), new Fields("dummyColumn"));
//                .newValuesStream()
//                .each(new Fields("year", "month", "day", "sku", "pname", "age", "state", "distrinctName", "brand", "views"), new Print(), new Fields("var"));


        return topology.build();
    }

    public static void main(String[] args) throws Exception {

        String kafkaZk = args[0];
        RealtimeUsersInformation topology = new RealtimeUsersInformation(kafkaZk);
        Config config = new Config();
        config.put(Config.TOPOLOGY_TRIDENT_BATCH_EMIT_INTERVAL_MILLIS, 2000);

        if (args != null && args.length > 1) {
            String name = args[1];
            String dockerIp = args[2];
            config.setNumWorkers(1);
            config.setMaxTaskParallelism(10);
            config.put(Config.NIMBUS_HOST, dockerIp);
            config.put(Config.NIMBUS_THRIFT_PORT, 6627);
            config.put(Config.STORM_ZOOKEEPER_PORT, 2181);
            config.put(Config.STORM_ZOOKEEPER_SERVERS, Arrays.asList(dockerIp));
            StormSubmitter.submitTopology(name, config, topology.buildTopology(name));
        } else {
            //LocalCluster cluster = new LocalCluster();
            //cluster.submitTopology("wordCounter", config, topology.buildTopology(name));
        }
    }
}
