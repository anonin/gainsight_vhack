package storm.kafka.trident.functions;

import java.util.*;
import java.text.*;
import java.sql.SQLException;
import storm.kafka.trident.mappings.ColumnMappings;
import backtype.storm.tuple.Values;
import storm.trident.operation.BaseFunction;
import storm.trident.operation.TridentCollector;
import storm.trident.tuple.TridentTuple;
import storm.kafka.trident.helpers.*;
import java.util.concurrent.TimeUnit;
public class EventFieldsForUsers extends BaseFunction {
    ColumnMappings           userIdToPincode;
    ColumnMappings           pidTobrand;
    ColumnMappings           pidToPname;
    ColumnMappings           pincodeToState;
    ColumnMappings           pincodeTodistrictName;
    ColumnMappings           pincodeTogeographicArea;
    ColumnMappings           userIdToDOB;
    DateFormat               formatter;
    HashMap <String, Long> userIdToLastActivity; //This will holds the mapping of users with last activity
    public static long lastts = 0;
    public EventFieldsForUsers() {
        try {
            formatter = new SimpleDateFormat("yy-MM-dd HH:mm:ss");
            userIdToLastActivity = new HashMap <String, Long> ();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    public void execute(TridentTuple tuple, TridentCollector collector) {
        String row = tuple.getStringByField("str");
        if (row != null) {
            String[] split = row.split("\t");
            try {
                if (split.length > 3) {
                    String ts = split[0];
                    String pincode = "-", brand = "-", state = "-", distrinctName = "-", searchString = "-", dob = "-", geographicArea = "-";
                    long age = 0, diff = 0, timestamp = 0;
                    String userId = split[1];
                    timestamp = (formatter.parse(ts).getTime()) / 1000; //seconds
                    String event = split[2];
                    if (event.equals("LogOut")) {
                       if (event.contains(userId)) {
                           userIdToLastActivity.remove(userId);
                       } 
                    } else {
                       userIdToLastActivity.put(userId, timestamp);
                    }
                    Iterator it = userIdToLastActivity.entrySet().iterator();
                    //Removing all users who are timedout taking out after 10 sec
                    while (it.hasNext()) {
                        Map.Entry pair = (Map.Entry)it.next();
                        long value = (Long)pair.getValue();
                        diff = timestamp - value;
                        if (diff > 10) {
                            it.remove();
                        }
                    }
                    if (lastts != timestamp) {
                        lastts = timestamp;
                        System.out.println(timestamp + " " + userIdToLastActivity.size() + " " );
                        collector.emit(new Values(timestamp, userIdToLastActivity.size()));
                    }
                }
            } catch (Exception e) {
                System.out.println("Error processing tuple " + e.getMessage());
            }
        }
    }
}
