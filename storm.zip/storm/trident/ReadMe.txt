use gainsight
"year", "month", "day", "sku", "pname", "age", "state", "distrinctName", "brand"
create table TrendingProducts
(
    year int,
    month int,
    day int,
    hour int,
    pname varchar(50),
    eventType varchar(50),
    event varchar(50),
    brand varchar(50),
    views int,
    txid int,
    primary key(year, month, day, hour, pname, eventType, event, brand)
)

create table TrendingProductsByGeo
(
    year int,
    month int,
    day int,
    hour int,
    pname varchar(50),
    geographicArea varchar(50),
    age int,
    views int,
    txid int,
    primary key(year, month, day, hour, pname, geographicArea, age)
)

create table UsersTracking
(
    timestamp int,
    activeUsers int,
    dummyColumn int,
    txid int,
    primary key(activeUsers)
)


create table userMaster
(
    userId varchar(100),
    emailId varchar(50),
    gender varchar(10),
    pincode int,
    dob timestamp,
    signupdate timestamp, 
    userName varchar(50),
    primary key(userId)
)

create table productMaster
(
    sku varchar(100),
    productsubFamily varchar(50),
    productFamily varchar(50),
    price DECIMAL(10,2),
    name varchar(50),
    categories varchar(50),
    brand varchar(20),
    description varchar(200),
    searchString varchar(200),
    primary key(sku)
)

create table pincodeMaster
(
    officename varchar(50),
    pincode varchar(20),
    officeType varchar(50),
    deliveryStatus varchar(50),
    divisionName varchar(50),
    regionName varchar(20),
    circleName varchar(50),
    taluk varchar(200),
    districtName varchar(50),
    stateName varchar(50),
    primary key(pincode)
)

LOAD DATA INFILE '/mnt/hackathon/data/users_master.csv' ignore INTO TABLE gainsight.userMaster FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 ROWS;
LOAD DATA INFILE '/mnt/hackathon/data/products_master.csv' ignore INTO TABLE gainsight.productMaster FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 ROWS;
LOAD DATA INFILE '/mnt/hackathon/data/all_india_pin_code.csv' ignore INTO TABLE gainsight.pincodeMaster FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 ROWS;

zip -d target/realtime-topology-1.0-jar-with-dependencies.jar defaults.yaml

Command to run topology
/mnt/apache-storm-0.9.2-incubating/bin/storm jar  target/realtime-topology-1.0-jar-with-dependencies.jar storm.kafka.trident.RealtimeDataPopulation localhost:2181 product 54.186.228.54
/mnt/apache-storm-0.9.2-incubating/bin/storm jar  target/realtime-topology-1.0-jar-with-dependencies.jar storm.kafka.trident.RealtimeDataPopulationForGeo localhost:2181 productForGeo 54.186.228.54
/mnt/apache-storm-0.9.2-incubating/bin/storm jar  target/realtime-topology-1.0-jar-with-dependencies.jar storm.kafka.trident.RealtimeUsersInformation localhost:2181 testingUsers 54.186.228.54
