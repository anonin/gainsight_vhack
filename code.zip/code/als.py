from pyspark.mllib.recommendation import ALS, MatrixFactorizationModel, Rating
from pyspark import SparkContext
import os
import sys

users = dict()
products = dict()
user_prod = dict()
output_file = sys.argv[2]
input_file = sys.argv[1]
f1 = open(output_file, "w+")

sc = SparkContext("local", "Web_Seen_reco")
# Load and parse the data
data = sc.textFile(input_file)
ratings = data.map(lambda l: l.split('\t')).map(lambda l: Rating(int(l[0]), int(l[1]), float(l[2])))

# Build the recommendation model using Alternating Least Squares
rank = 30
numIterations = 100
model = ALS.trainImplicit(ratings, rank, iterations=numIterations, lambda_=0.01, alpha = 0.03, seed=10)
# Evaluate the model on training data
user_features = model.userFeatures().collect()
product_features = model.productFeatures().collect()

for user in user_features:
    user_vec = user[1]
    userId = user[0]
    for prod in product_features:
        prod_vec = prod[1]
        prodId = prod[0]
        val =0
        for i in range(len(user_vec)):
            val = val + user_vec[i]*prod_vec[i]               
        f1.write(str(k)+"\t"+str(k1)+"\t"+str(val)+"\n")
"""
testdata = ratings.map(lambda p: (p[0], p[1]))
predictions = model.predictAll(testdata).map(lambda r: ((r[0], r[1]), r[2]))
ratesAndPreds = ratings.map(lambda r: ((r[0], r[1]), r[2])).join(predictions)
"""



# Save and load model
#model.save(sc, "myModelPath")
#sameModel = MatrixFactorizationModel.load(sc, "myModelPath")
