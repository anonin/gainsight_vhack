import nltk
import csv
nltk.download('maxent_treebank_pos_tagger')
alpha = 0
f2 = open("nltk_output.txt","w+")
with open("sample_product.csv") as csvfile:
    f1 = csv.reader(csvfile,delimiter=",")
    print f1
    for line in f1:
        if len(line) != 9 or alpha == 0:
            alpha = 1
            continue
        for i in range(len(line)):

            line[i] = line[i].replace("\"", "")
            line[i] = line[i].replace("<br>", "")
            line[i] = line[i].replace("</br>", "")
            line[i] = line[i].replace("<b>", "")
            line[i] = line[i].replace("</b>", "")

            if len(line) != 9:
                print len(line)

            combined_string = ""
            if i ==6 and line[6] != "" and line[6] != "NULL":
                combined_string = line[6].lower().split("_")[1]
            if i == 7 and line[7] != "" and line[7] != "NULL":
                combined_string = combined_string+line[7].lower()
            if i == 8 and line[8] != "" and line[8] != "NULL":
                combined_string = combined_string+line[8].lower()
            text = nltk.word_tokenize(combined_string)
            fragments = nltk.pos_tag(text)
            for data in  fragments:
                if data[1].startswith("NN") or data[1].startswith("RB") or data[1].startswith("JJ"):
                    f2.write(str(line[0])+"\t"+str(combined_string)+"\t"+str(data[0])+"\n")
