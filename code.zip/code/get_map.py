
users = dict()
prods = dict()
i=0
j=0
f2 = open("spark_cart_data_web.txt","w+")
f3 = open("user_map_web.txt","w+")
f4 = open("prod_map_web.txt","w+")

with open("search_data_web.txt") as f1:
    for line in f1:
        line = line.strip().split("\t")
        if len(line) != 3:
            continue
        if line[0] not in users:
            users[line[0]] = i
            i = i+1
        if line[1] not in prods:
            prods[line[1]] = j
            j = j+1
        f2.write(str(users[line[0]])+"\t"+str(prods[line[1]])+"\t"+str(line[2])+"\n")
        f3.write(str(line[0])+"\t"+str(users[line[0]])+"\n")
        f4.write(str(line[1])+"\t"+str(prods[line[1]])+"\n")
f2.close()
f3.close()
f4.close()

