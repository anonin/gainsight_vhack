import datetime, dateutil.parser
from collections import defaultdict
import time
from time import strftime
search_products = dict()
cart_products = dict()
returned_products =dict()
seen_products = dict()
removed_products = dict()
bought_products = dict()
user_web = dict()
user_mobile = dict()
products = dict()
alpha = 0
i=0
j=0
t=0
with open("./data/events_feed.csv") as f1:
    for line in f1:
        line = line.replace("\"","")
        line = line.strip().split(",")
        
        if len(line) != 8 or alpha == 0:
            alpha = 1
            continue
        d = dateutil.parser.parse(line[0])
        s  = d.strftime("%Y-%m-%d %H:%M:%S")
        tstp=time.mktime(datetime.datetime.strptime(s,'%Y-%m-%d %H:%M:%S').timetuple())
        curr_time = time.time()
        if curr_time - tstp <= 7*24*3600:
            if line[1] not in user_web and line[3] == "WEB_PAGE":
                user_web[line[1]] =  str(i)
                i = i+1
            if line[1] not in user_mobile and line[3] == "MOBILE":
                user_mobile[line[1]] =  str(j)
                j= j+1
            if line[4] != "":
                products[line[4]] = str(t)
                t= t+1
            if line[2] == "ProductPage" and line[3]=="WEB_PAGE":
                if (user_web[line[1]],line[4],"web") not in seen_products:
                    seen_products[(user_web[line[1]],line[4], "web")] = 1
                else:
                    seen_products[(user_web[line[1]],line[4], "web")] +=1

            if line[2] == "ProductPage" and line[3] =="MOBILE":
                if (user_mobile[line[1]],line[4],"mobile") not in seen_products:
                   seen_products[(user_mobile[line[1]],line[4], "mobile")] = 1
                else:
                    seen_products[(user_mobile[line[1]],line[4], "mobile")] += 1
            if line[2] == "Search" and line[3] == "WEB_PAGE":
                if (user_web[line[1]], line[4], "web") not in search_products:
                    search_products[(user_web[line[1]], line[4], "web")] = 1
                else:
                    search_products[(user_web[line[1]], line[4], "web")] +=1
            if line[2] == "Search" and line[3] == "MOBILE":
                if (user_mobile[line[1]], line[4], "mobile") not in search_products:
                    search_products[(user_mobile[line[1]], line[4], "mobile")] = 1
                else:
                    search_products[(user_mobile[line[1]], line[4], "mobile")] +=1
            if line[2] == "OrderPlaced" and line[3] == "WEB_PAGE":
                if (user_web[line[1]], line[4], "web") not in bought_products:
                    bought_products[(user_web[line[1]], line[4], "web")] = 1
                else:
                    bought_products[(user_web[line[1]],line[4],"web")] +=1
            if line[2] == "OrderPlaced" and line[3]=="MOBILE":
                if(user_mobile[line[1]],line[4], "mobile") not in bought_products:
                    bought_products[(user_mobile[line[1]],line[4], "mobile")] = 1
                else:
                    bought_products[(user_mobile[line[1]],line[4], "mobile")] +=1

            if line[2] == "OrderReturn" and line[3] == "WEB_PAGE":
                if (user_web[line[1]], line[4], "web") not in returned_products:
                    returned_products[(user_web[line[1]], line[4], "web")] = 1
                else:
                    returned_products[(user_web[line[1]],line[4],"web")] +=1
            if line[2] == "OrderReturn" and line[3]=="MOBILE":
                if(user_mobile[line[1]],line[4], "mobile") not in returned_products:
                    returned_products[(user_mobile[line[1]],line[4], "mobile")] = 1
                else:
                    returned_products[(user_mobile[line[1]],line[4], "mobile")] +=1

            if line[2] == "AddToCart" and line[3] == "WEB_PAGE":
                if (user_web[line[1]], line[4], "web") not in cart_products:
                    cart_products[(user_web[line[1]], line[4], "web")] = 1
                else:
                    cart_products[(user_web[line[1]],line[4],"web")] +=1
            if line[2] == "AddToCart" and line[3]=="MOBILE":
                if(user_mobile[line[1]],line[4], "mobile") not in cart_products:
                    cart_products[(user_mobile[line[1]],line[4], "mobile")] = 1
                else:
                    cart_products[(user_mobile[line[1]],line[4], "mobile")] +=1

            if line[2] == "RemoveFromCart" and line[3] == "WEB_PAGE":
                if (user_web[line[1]], line[4], "web") not in removed_products:
                    removed_products[(user_web[line[1]], line[4], "web")] = 1
                else:
                    removed_products[(user_web[line[1]],line[4],"web")] +=1
            if line[2] == "RemoveFromCart" and line[3]=="MOBILE":
                if(user_mobile[line[1]],line[4], "mobile") not in removed_products:
                    removed_products[(user_mobile[line[1]],line[4], "mobile")] = 1
                else:
                    removed_products[(user_mobile[line[1]],line[4], "mobile")] +=1
           

for k in bought_products.keys():
    for k1,v1 in returned_products.items():
        if k1==k:
            bought_products[k] = bought_products[k] - v1
for k in cart_products.keys():
    for k1,v1 in removed_products.items():
        if k1==k:
            cart_products[k] = cart_products[k] - v1

f2 = open("seen_data_web.txt","w+")
f3 = open("seen_data_mobile.txt","w+")
for k,v in seen_products.items():
    if k[2] == "web" and k[0] != "" and k[1] != "" and k[1] in products:
        f2.write(str(k[0])+"\t"+str(products[k[1]])+"\t"+str(v)+"\n")
    if k[2] == "mobile" and k[0] != "" and k[1] != "" and k[1] in products:
        f3.write(str(k[0])+"\t"+str(products[k[1]])+"\t"+str(v)+"\n")

f2.close()
f3.close()

f2 = open("bought_data_web.txt","w+")
f3 = open("bought_data_mobile.txt","w+")

for k,v in bought_products.items():
    if k[2] == "web" and k[0] != "" and k[1] != "" and k[1] in products:
        f2.write(str(k[0])+"\t"+str(products[k[1]])+"\t"+str(v)+"\n")
    if k[2] =="mobilw" and k[0] != "" and k[1] != "" and k[1] in products:
        f3.write(str(k[0])+"\t"+str(products[k[1]])+"\t"+str(v)+"\n")

f2.close()
f3.close()

f2 = open("cart_data_web.txt","w+")
f3 = open("cart_data_mobile.txt","w+")

for k,v in cart_products.items():
    if k[2] == "web" and k[0] != "" and k[1] != "" and k[1] in products:
        f2.write(str(k[0])+"\t"+str(products[k[1]])+"\t"+str(v)+"\n")
    if k[2] == "mobile" and k[0] != "" and k[1] != "" and k[1] in products:
        f3.write(str(k[0])+"\t"+str(products[k[1]])+"\t"+str(v)+"\n")
f2.close()
f3.close()

f2 = open("search_data_web.txt","w+")
f3 = open("search_data_mobile.txt","w+")

for k,v in search_products.items():
    if k[2] == "web" and k[0] != "" and k[1] != "" and k[1] in products:
        f2.write(str(k[0])+"\t"+str(products[k[1]])+"\t"+str(v)+"\n")
    if k[2] =="mobile" and k[0] != "" and k[1] != "" and k[1] in products:
        f3.write(str(k[0])+"\t"+str(products[k[1]])+"\t"+str(v)+"\n")
f2.close()
f3.close()

f2 = open("user_map_web.txt","w+")

for k,v in user_web.items():
    f2.write(str(k)+"\t"+str(v)+"\n")
f2.close()

f2 = open("user_map_mobile.txt","w+")

for k,v in user_mobile.items():
    f2.write(str(k)+"\t"+str(v)+"\n")
f2.close()

f2 = open("product_map.txt","w+")
for k,v in products.items():
    f2.write(str(k)+"\t"+str(v)+"\n")
f2.close()    
