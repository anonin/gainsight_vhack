from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import NMF
from collections import defaultdict
import numpy as np
pids = defaultdict(set)
with open("nltk_output.txt") as f1:
    for line in f1:
        line = line.strip().split("\t")
        if len(line) != 3:
            continue
        pids[line[0]].add(line[2])

data = []
index = dict()
i =0
for k in pids.keys():
    temp =""
    for d in pids[k]:
        temp = temp + str(d)
    data.append(temp)
    index[i] = k
    del temp
    i = i+1
n_features = 1000

vectorizer = TfidfVectorizer(max_df=0.95, min_df=2, max_features=n_features,
                                     stop_words='english')
tfidf = vectorizer.fit_transform(data)
n_topics = 50

nmf = NMF(n_components=n_topics, init="random", random_state=1).fit(tfidf)
print type(nmf.transform(tfidf[1]))

print nmf.transform(tfidf[0]).dot(nmf.transform(tfidf[1]).T)[0][0]
f2 = open("nmf_output.txt","w+")

for k,v in index.items():
    for k1,v1 in index.items():
        if k != k1:
            similarity = nmf.transform(tfidf[k]).dot(nmf.transform(tfidf[k1]).T)[0][0]
            f2.write(str(index[k])+"\t"+str(index[k1])+"\t"+str(similarity)+"\n")


f2.close()



