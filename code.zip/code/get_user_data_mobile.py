from collections import defaultdict

user_cart = defaultdict(set)
user_bought = dict()

with open("cart_data_mobile.txt") as f1:
    for line in f1:
        line=line.strip().split("\t")
        if len(line) !=3:
            continue
        user_cart[line[0]].add(line[1])

with open("bought_data_mobile.txt") as f1:
    for line in f1:
        line=line.strip().split("\t")
        if len(line) != 3:
            continue
        user_bought[line[0]]=1

f2 = open("user_to_be_sent_app","w+")
for k in user_cart.keys():
    if k not in user_bought:
        for prod in user_cart[k]:
            f2.write(str(k)+"\t"+str(prod)+"\n")
f2.close()
